# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'd1c0b6ce8c6d8a8fa8d50771ec52a47c158a682f2c6425efeae844ab1c7f592aabef43fab7b563efdaf77ecad31d31c4be8ac4aed0f772e4d6d6bf7900d28af3'